/**
 * 
 */
package hintoso_CSCI201L_Lab1;

/**
 * @author eddowh
 *
 */
public class HelloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// System.out.println("Hello World");
		String s = "Hello World!";
		// s = null;
		s.length();
	}

}
